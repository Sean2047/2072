# 2072 知识库网站原型（Part 4 机制词条）

建立：2026-07-15（D-048）。目的：用实物裁定词条粒度、元数据 schema、渐进披露与链接交互，作为生成器正式选型（D-049）与 Part 4 全量切分的依据。

## 使用

```
python3 build.py                     # 构建站点 + 关联数据库
python3 check_entries.py             # 词条校对与对齐检查（D-049）
python3 check_entries.py --update-lock  # 漂移消化后刷新哈希基线
```

然后浏览器打开 `site/index.html`。构建报告（链接解析统计）打印到控制台。

## 结构

- `entries/*.md` —— 词条源文件：YAML frontmatter + 可选正文
  - 章节词条含 `extract: 4.9.1` 字段：构建时按节号从 `../2072_v149.md` 提取原文，**迁移期内 v149 是唯一事实源，词条文件不复制正文**（避免双份维护漂移）
  - 概念词条正文手写：词典定义原文 + "机制展开"链接映射，不重复机制推导
  - 索引词条（type: 索引）：提取二级节导语 + `children` 列表自动生成
- `build.py` —— 零依赖构建脚本（Python 标准库）；输出站点 + `site/graph.json`（知识图谱：带类型边 ref/term/related/child）+ `site/entries.db`（SQLite，视图 backlink_count/orphans）
- `check_entries.py` —— 校对对齐脚本（D-049）：schema 校验、layer 与分派清单对账、原文哈希漂移检测、引用分级、切分进度对账、"见于"表重生成（登记项12）
- `entries.lock.json` —— 原文哈希基线（对齐记录，应入版本管理）
- `assets/` —— 样式与交互（悬停预览、首页多维筛选）
- `site/` —— 生成产物（可整目录删除重建，不入版本管理）

注意（VM 挂载层）：SQLite 先在 /tmp 建库再拷回；git 不得在 VM 侧对本目录操作（详见重整工作文件待办遗留②⑤）。

## 已验证的机制（对应 D-045/